package co.edu.unbosque.ProyectoFinal.Controller;

import co.edu.unbosque.ProyectoFinal.Model.Personas;
import co.edu.unbosque.ProyectoFinal.Model.Paquetes;
import co.edu.unbosque.ProyectoFinal.Repository.PersonasRepository;
import co.edu.unbosque.ProyectoFinal.Repository.PaquetesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/apilouis")
public class Controller {
    @Autowired
    private PersonasRepository personasRepository;
    @Autowired
    private PaquetesRepository paquetesRepository;

    // Endpoints para la entidad Personas
    @PostMapping("/aggpersonas")
    public ResponseEntity<Personas> createPersonas(@RequestParam String nombre, @RequestParam int cedula) {
        Personas personas = new Personas();
        personas.setNombre(nombre);
        personas.setCedula(cedula);

        Personas createdPersonas = personasRepository.save(personas);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdPersonas);
    }
    @GetMapping("/personas")
    public ResponseEntity<List<Personas>> getAllPersonas() {
        List<Personas> personasList = personasRepository.findAll();
        if (personasList.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(personasList);
        }
        return ResponseEntity.status(HttpStatus.OK).body(personasList);
    }

    @GetMapping("/personas/{id}")
    public ResponseEntity<Personas> getPersonasById(@PathVariable Integer id) {
        Optional<Personas> optionalPersonas = personasRepository.findById(id);
        return optionalPersonas.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PutMapping("/editpersonas/{id}")
    public ResponseEntity<Personas> updatePersonas(@PathVariable Integer id, @RequestParam String nombre, @RequestParam int cedula) {
        Optional<Personas> optionalPersonas = personasRepository.findById(id);
        if (optionalPersonas.isPresent()) {
            Personas existentPersonas = optionalPersonas.get();
            existentPersonas.setNombre(nombre);
            existentPersonas.setCedula(cedula);
            return ResponseEntity.ok(personasRepository.save(existentPersonas));
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/delpersonas/{id}")
    public ResponseEntity<String> deletePersonas(@PathVariable Integer id) {
        Optional<Personas> optionalPersonas = personasRepository.findById(id);
        if (optionalPersonas.isPresent()) {
            personasRepository.deleteById(id);
            return ResponseEntity.ok("Personas deleted");
        }
        return ResponseEntity.notFound().build();
    }

    // Endpoints para la entidad Paquetes

    @PostMapping("/aggpack")
    public ResponseEntity<Paquetes> createPaquetes(@RequestParam int cc, @RequestParam int tamaño, @RequestParam int peso, @RequestParam String paisenvio, @RequestParam String paisrecibo, @RequestParam boolean confiscado, @RequestParam String envio, @RequestParam String recibir) {
        Paquetes paquetes = new Paquetes();
        paquetes.setCc(cc);
        paquetes.setTamaño(tamaño);
        paquetes.setPeso(peso);
        paquetes.setPaisenvio(paisenvio);
        paquetes.setPaisrecibo(paisrecibo);
        paquetes.setConfiscado(confiscado);
        paquetes.setEnvio(envio);
        paquetes.setRecibir(recibir);

        Paquetes createdPaquetes = paquetesRepository.save(paquetes);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdPaquetes);
    }

    @GetMapping("/paquetes")
    public ResponseEntity<List<Paquetes>> getAllPaquetes() {
        List<Paquetes> paquetesList = paquetesRepository.findAll();
        if (paquetesList.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(paquetesList);
        }
        return ResponseEntity.status(HttpStatus.OK).body(paquetesList);
    }

    @GetMapping("/paquetes/{id}")
    public ResponseEntity<Paquetes> getPaquetesById(@PathVariable Integer id) {
        Optional<Paquetes> optionalPaquetes = paquetesRepository.findById(id);
        return optionalPaquetes.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PutMapping("/editpaquetes/{id}")
    public ResponseEntity<Paquetes> updatePaquetes(@PathVariable Integer id, @RequestParam int cc, @RequestParam int tamaño, @RequestParam int peso, @RequestParam String paisenvio, @RequestParam String paisrecibo, @RequestParam boolean confiscado) {
        Optional<Paquetes> optionalPaquetes = paquetesRepository.findById(id);
        if (optionalPaquetes.isPresent()) {
            Paquetes existentPaquetes = optionalPaquetes.get();
            existentPaquetes.setCc(cc);
            existentPaquetes.setTamaño(tamaño);
            existentPaquetes.setPeso(peso);
            existentPaquetes.setPaisenvio(paisenvio);
            existentPaquetes.setPaisrecibo(paisrecibo);
            existentPaquetes.setConfiscado(confiscado);
            return ResponseEntity.ok(paquetesRepository.save(existentPaquetes));
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/delpaquetes/{id}")
    public ResponseEntity<String> deletePaquetes(@PathVariable Integer id) {
        Optional<Paquetes> optionalPaquetes = paquetesRepository.findById(id);
        if (optionalPaquetes.isPresent()) {
            paquetesRepository.deleteById(id);
            return ResponseEntity.ok("Paquetes deleted");
        }
        return ResponseEntity.notFound().build();
    }
}
