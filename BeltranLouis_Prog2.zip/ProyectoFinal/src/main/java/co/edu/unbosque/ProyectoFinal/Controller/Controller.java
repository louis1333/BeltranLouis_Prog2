package co.edu.unbosque.ProyectoFinal.Controller;

import co.edu.unbosque.ProyectoFinal.Model.Personas;
import co.edu.unbosque.ProyectoFinal.Model.Paquetes;
import co.edu.unbosque.ProyectoFinal.Repository.PersonasRepository;
import co.edu.unbosque.ProyectoFinal.Repository.PaquetesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/apilouis")
public class Controller {
    @Autowired
    private PersonasRepository personasRepository;

    // Endpoints para la entidad Personas
    @PostMapping("/aggpersonas")
    public ResponseEntity<Personas> createPersonas(@RequestParam String nombre, @RequestParam int cedula) {
        Personas personas = new Personas();
        personas.setNombre(nombre);
        personas.setCedula(cedula);

        Personas createdPersonas = personasRepository.save(personas);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdPersonas);
    }
    @GetMapping("/personas")
    public ResponseEntity<List<Personas>> getAllPersonas() {
        List<Personas> personasList = personasRepository.findAll();
        if (personasList.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(personasList);
        }
        return ResponseEntity.status(HttpStatus.OK).body(personasList);
    }

    @GetMapping("/personas/{id}")
    public ResponseEntity<Personas> getPersonasById(@PathVariable Integer id) {
        Optional<Personas> optionalPersonas = personasRepository.findById(id);
        return optionalPersonas.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PutMapping("/editpersonas/{id}")
    public ResponseEntity<Personas> updatePersonas(@PathVariable Integer id, @RequestParam String nombre, @RequestParam int cedula) {
        Optional<Personas> optionalPersonas = personasRepository.findById(id);
        if (optionalPersonas.isPresent()) {
            Personas existentPersonas = optionalPersonas.get();
            existentPersonas.setNombre(nombre);
            existentPersonas.setCedula(cedula);
            return ResponseEntity.ok(personasRepository.save(existentPersonas));
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/delpersonas/{id}")
    public ResponseEntity<String> deletePersonas(@PathVariable Integer id) {
        Optional<Personas> optionalPersonas = personasRepository.findById(id);
        if (optionalPersonas.isPresent()) {
            personasRepository.deleteById(id);
            return ResponseEntity.ok("Personas deleted");
        }
        return ResponseEntity.notFound().build();
    }


}
