package co.edu.unbosque.ProyectoFinal.Controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import co.edu.unbosque.ProyectoFinal.Model.Paquetes;
import co.edu.unbosque.ProyectoFinal.Repository.PaquetesRepository;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.PDPageContentStream;

@Controller
public class PaquetesPdfController {
    private final PaquetesRepository paquetesRepository;
    
    @Value("${pdf.pathh}")
    private String pdfPath;

    public PaquetesPdfController(PaquetesRepository paquetesRepository) {
        this.paquetesRepository = paquetesRepository;
    }

    @GetMapping("/download-paquetes-pdf")
    public ResponseEntity<FileSystemResource> downloadPaquetesPdf() throws IOException {
        // Obtener la lista de paquetes desde la base de datos
        List<Paquetes> paquetes = paquetesRepository.findAll();

        // Crear un nuevo documento PDF
        PDDocument document = new PDDocument();

        // Crear una nueva página en el documento
        PDPage page = new PDPage(PDRectangle.A4);
        document.addPage(page);

        // Crear el contenido del PDF
        PDPageContentStream contentStream = new PDPageContentStream(document, page);
        contentStream.setFont(PDType1Font.HELVETICA_BOLD, 12);
        contentStream.beginText();
        contentStream.newLineAtOffset(50, 700);
        contentStream.showText("Lista de Paquetes");
        contentStream.newLine();
        contentStream.setFont(PDType1Font.HELVETICA, 12);

        for (Paquetes paquete : paquetes) {
            contentStream.showText("ID: " + paquete.getId());
            contentStream.newLine();
            contentStream.showText("CC: " + paquete.getCc());
            contentStream.newLine();
            contentStream.showText("Tamaño: " + paquete.getTamaño());
            contentStream.newLine();
            contentStream.showText("Peso: " + paquete.getPeso());
            contentStream.newLine();
            contentStream.showText("Envío: " + paquete.getEnvio());
            contentStream.newLine();
            contentStream.showText("Recibir: " + paquete.getRecibir());
            contentStream.newLine();
            contentStream.showText("País de Envío: " + paquete.getPaisenvio());
            contentStream.newLine();
            contentStream.showText("País de Recibo: " + paquete.getPaisrecibo());
            contentStream.newLine();
            contentStream.showText("Confiscado: " + paquete.isConfiscado());
            contentStream.newLine();
            contentStream.newLine(); // Agregar una nueva línea para separar los paquetes
        }

        contentStream.endText();
        contentStream.close();

        // Guardar el PDF en la ubicación temporal configurada
        String pdfFileName = savePdf(document);

        // Construir la ruta completa del archivo PDF
        String fullPath = pdfPath + pdfFileName;

        // Crear un objeto FileSystemResource para el archivo PDF
        File file = new File(fullPath);
        FileSystemResource resource = new FileSystemResource(file);

        // Configurar las cabeceras de la respuesta
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + pdfFileName);

        // Devolver la respuesta con el archivo PDF
        return ResponseEntity.ok()
                .headers(headers)
                .contentLength(file.length())
                .contentType(MediaType.APPLICATION_PDF)
                .body(resource);
    }

    private String savePdf(PDDocument document) throws IOException {
        // Generar un nombre único para el archivo PDF
        String pdfFileName = "paquetes-" + System.currentTimeMillis() + ".pdf";

        // Guardar el documento PDF en la ubicación configurada
        String fullPath = pdfPath + pdfFileName;
        document.save(fullPath);

        // Cerrar el documento
        document.close();

        return pdfFileName;
    }
}
