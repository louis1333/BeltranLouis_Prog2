package co.edu.unbosque.ProyectoFinal.Controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import co.edu.unbosque.ProyectoFinal.Model.Personas;
import co.edu.unbosque.ProyectoFinal.Repository.PersonasRepository;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.PDPageContentStream;

@Controller
public class PdfController {
    private final PersonasRepository personasRepository;
    
    @Value("${pdf.path}")
    private String pdfPath;

    public PdfController(PersonasRepository personasRepository) {
        this.personasRepository = personasRepository;
    }

    @GetMapping("/download-pdf")
    public ResponseEntity<FileSystemResource> downloadPdf() throws IOException {
        // Obtener la lista de personas desde la base de datos
        List<Personas> personas = personasRepository.findAll();

        // Crear un nuevo documento PDF
        PDDocument document = new PDDocument();

        // Crear una nueva página en el documento
        PDPage page = new PDPage(PDRectangle.A4);
        document.addPage(page);

        // Crear el contenido del PDF
        PDPageContentStream contentStream = new PDPageContentStream(document, page);
        contentStream.setFont(PDType1Font.HELVETICA_BOLD, 12);
        contentStream.beginText();
        contentStream.newLineAtOffset(50, 700);
        contentStream.showText("Lista de Personas");
        contentStream.newLine();
        contentStream.setFont(PDType1Font.HELVETICA, 12);

        for (Personas persona : personas) {
            contentStream.drawString("ID: " + persona.getId());
            contentStream.newLine();
            contentStream.drawString("Nombre: " + persona.getNombre());
            contentStream.newLine();
            contentStream.drawString("Cedula: " + persona.getCedula());
            contentStream.newLine();
            contentStream.newLine(); // Agregar una nueva línea para separar las entradas
        }

        contentStream.endText();
        contentStream.close();

        // Guardar el PDF en la ubicación temporal configurada
        String pdfFileName = savePdf(document);

        // Construir la ruta completa del archivo PDF
        String fullPath = pdfPath + pdfFileName;

        // Crear un objeto FileSystemResource para el archivo PDF
        File file = new File(fullPath);
        FileSystemResource resource = new FileSystemResource(file);

        // Configurar las cabeceras de la respuesta
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + pdfFileName);

        // Devolver la respuesta con el archivo PDF
        return ResponseEntity.ok()
                .headers(headers)
                .contentLength(file.length())
                .contentType(MediaType.APPLICATION_PDF)
                .body(resource);
    }

    private String savePdf(PDDocument document) throws IOException {
        // Generar un nombre único para el archivo PDF
        String pdfFileName = "personas-" + System.currentTimeMillis() + ".pdf";

        // Guardar el documento PDF en la ubicación configurada
        String fullPath = pdfPath + pdfFileName;
        document.save(fullPath);

        // Cerrar el documento
        document.close();

        return pdfFileName;
    }
}
