package co.edu.unbosque.ProyectoFinal.Model;




import java.util.Date;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
@Entity
public class Paquetes {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	
	private int cc;
	private int tamaño;
	private int peso;
	private String envio;
	private String recibir;
	private String paisenvio;
	private String paisrecibo;
	private boolean confiscado;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public int getCc() {
		return cc;
	}
	public void setCc(int cc) {
		this.cc = cc;
	}
	public int getTamaño() {
		return tamaño;
	}
	public void setTamaño(int tamaño) {
		this.tamaño = tamaño;
	}
	public int getPeso() {
		return peso;
	}
	public void setPeso(int peso) {
		this.peso = peso;
	}
	public String getEnvio() {
		return envio;
	}
	public void setEnvio(String envio) {
		this.envio = envio;
	}
	public String getRecibir() {
		return recibir;
	}
	public void setRecibir(String recibir) {
		this.recibir = recibir;
	}
	public String getPaisenvio() {
		return paisenvio;
	}
	public void setPaisenvio(String paisenvio) {
		this.paisenvio = paisenvio;
	}
	public String getPaisrecibo() {
		return paisrecibo;
	}
	public void setPaisrecibo(String paisrecibo) {
		this.paisrecibo = paisrecibo;
	}
	public boolean isConfiscado() {
		return confiscado;
	}
	public void setConfiscado(boolean confiscado) {
		this.confiscado = confiscado;
	}
	
}
