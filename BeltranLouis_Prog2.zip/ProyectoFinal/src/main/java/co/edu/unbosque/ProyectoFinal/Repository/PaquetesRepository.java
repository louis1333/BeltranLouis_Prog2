package co.edu.unbosque.ProyectoFinal.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import co.edu.unbosque.ProyectoFinal.Model.Paquetes;




public interface PaquetesRepository extends CrudRepository<Paquetes, Integer>{
	public Optional<Paquetes>findById(Integer id);
	public List<Paquetes> findAll();
}
