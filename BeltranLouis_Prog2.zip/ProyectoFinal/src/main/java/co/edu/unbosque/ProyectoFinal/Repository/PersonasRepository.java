package co.edu.unbosque.ProyectoFinal.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import co.edu.unbosque.ProyectoFinal.Model.Personas;


public interface PersonasRepository extends CrudRepository<Personas, Integer>{
	public Optional<Personas>findById(Integer id);
	public List<Personas> findAll();
}
