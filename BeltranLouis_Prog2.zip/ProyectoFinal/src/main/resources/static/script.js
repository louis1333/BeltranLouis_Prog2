function registrarPersona() {
    var cc = document.getElementById("cc").value;
    var nombre = document.getElementById("nombre").value;

    // Crear el objeto persona con los datos
    var persona = {
        cc: cc,
        nombre: nombre
    };

    // Enviar la solicitud al servidor
    fetch('/apilouis/aggpersonas', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(persona)
    })
    .then(response => response.json())
    .then(data => {
        // Mostrar la respuesta del servidor
        console.log(data);

        // Limpiar los campos después del registro
        document.getElementById("cc").value = "";
        document.getElementById("nombre").value = "";
    })
    .catch(error => {
        console.error('Error al agregar persona:', error);
    });
}




