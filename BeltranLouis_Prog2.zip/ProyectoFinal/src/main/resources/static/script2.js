function registrarpaquete() {
  var cc = document.getElementById("cc").value;
  var tamaño = parseInt(document.getElementById("tamaño").value);
  var peso = parseInt(document.getElementById("peso").value);
  var envio = document.getElementById("envio").value;

  // Calcula la fecha de recibir sumando 30 días a la fecha de envio
  var envioDate = new Date(envio);
  var recibirDate = new Date(envioDate.getTime() + 30 * 24 * 60 * 60 * 1000);
  var recibir = recibirDate.toISOString().split('T')[0];

  var paisenvio = document.getElementById("paisenvio").value;
  var paisrecibo = document.getElementById("paisrecibo").value;
  var confiscado = (tamaño > 5 || peso > 300);

  var paquete = {
    cc: parseInt(cc),
    tamaño: tamaño,
    peso: peso,
    envio: envio,
    recibir: recibir,
    paisenvio: paisenvio,
    paisrecibo: paisrecibo,
    confiscado: confiscado
  };

  fetch('/apilouis/aggpack', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(paquete)
  })
    .then(response => response.json())
    .then(data => {
      // Mostrar la respuesta del servidor
      console.log(data);

      // Limpiar los campos después del registro
      document.getElementById("cc").value = "";
      document.getElementById("tamaño").value = "";
      document.getElementById("peso").value = "";
      document.getElementById("envio").value = "";
      document.getElementById("recibir").value = "";
      document.getElementById("paisenvio").value = "";
      document.getElementById("paisrecibo").value = "";
    })
    .catch(error => {
      console.error('Error al agregar paquete:', error);
    });
}

document.addEventListener("DOMContentLoaded", function () {
  document.getElementById("envio").addEventListener("change", function () {
    var envioDate = new Date(this.value);
    var recibirDate = new Date(envioDate.getTime() + 30 * 24 * 60 * 60 * 1000);
    var recibir = recibirDate.toISOString().split('T')[0];
    document.getElementById("recibir").value = recibir;
  });
});
