function registrarpaquete() {
    var cc = document.getElementById("cc").value;
    var tamaño = document.getElementById("tamaño").value;
    var peso = document.getElementById("peso").value;
    var envio = document.getElementById("envio").value;
    var paisenvio = document.getElementById("paisenvio").value;
    var paisrecibo = document.getElementById("paisrecibo").value;

    var paquete = {
  "tamaño": 0,
  "peso": 0,
  "envio": "string",
  "recibir": "string",
  "paisenvio": "string",
  "paisrecibo": "string",
  "confiscado": true,
  "cc": 0
    };

    fetch('/apilouis/aggpack', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(paquete)
    })
    .then(response => response.json())
    .then(data => {
        // Mostrar la respuesta del servidor
        console.log(data);

        // Limpiar los campos después del registro
        document.getElementById("cc").value = "";
        document.getElementById("tamaño").value = "";
        document.getElementById("peso").value = "";
        document.getElementById("envio").value = "";
        document.getElementById("paisenvio").value = "";
        document.getElementById("paisrecibo").value = "";
    })
    .catch(error => {
        console.error('Error al agregar paquete:', error);
    });
}
